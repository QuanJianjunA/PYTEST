# データフロー分析報告書: {ROOT_SESSION_ID}
## 📋 基本情報
| 項目 | 値 |
|------|-----|
| 対象ルートSession | {ROOT_SESSION_ID} |
| 分析実施日 | {DATE} |
| 解析対象Session数 | {SESSION_COUNT} |
| 分析深度 | {MAX_DEPTH} レベル |

---
## 📊 データフロー全体図
```mermaid
graph TD
{MERMAID_NODES_AND_LINKS}


## 🔍 データフロー詳細 (Session単位分析)

<!-- ========== 繰り返しブロック：1Sessionごとこのブロックを複製 ========== -->
▶ {SESSION_ID}（{SESSION_NAME}）
パッケージ: {PACKAGE} | プログラムID: {PROG_ID}

セッションの概要 (簡略版): {SHORT_DESC}

セッションの概要 (詳細版):
1. {DETAIL_LINE1}
2. {DETAIL_LINE2}
3. {DETAIL_LINE3}

使用テーブル一覧:

| **テーブル名** | **説明** | **操作** |
| ---- | ---- | ---- |
| {TABLE1} | {TABLE1_DESC} | {OP1} |
| {TABLE2} | {TABLE2_DESC} | {OP2} |

処理詳細:
1. {PROC_LINE1}
2. {PROC_LINE2}
    ○ {SUB_ITEM1}
    ○ {SUB_ITEM2}
3. {PROC_LINE3}

---
<!-- ========== 次のSession ここから再開 ========== -->
▶ {SESSION_ID2}（{SESSION_NAME2}）
パッケージ: {PACKAGE2} | プログラムID: {PROG_ID2}

セッションの概要 (簡略版): {SHORT_DESC2}

セッションの概要 (詳細版):
1. {DETAIL2_LINE1}
2. {DETAIL2_LINE2}

使用テーブル一覧:

| **テーブル名** | **説明** | **操作** |
| ---- | ---- | ---- |
| {TABLE_A} | {TABLE_A_DESC} | {OP_A} |

処理詳細:
1. {PROC2_LINE1}
    ○ {SUB2_ITEM1}
    ○ {SUB2_ITEM2}

---

## 📊 データフロー全体図
```mermaid
graph TD
{MERMAID_NODES_AND_LINKS}


## 📈 テーブル間カラムマッピング
### データ流チェーン## 
{DATA_CHAIN_TEXT}
