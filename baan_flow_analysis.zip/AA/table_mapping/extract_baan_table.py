import re
import os
import csv
import json

# ========== 配置：当前文件夹，不用子目录 ==========
SRC_FOLDER = "."
OUTPUT_CSV = "table_summary.csv"
MAPPING_JSON = "table_mapping.json"
# ==============================================

pat_table_decl = re.compile(r'^\s*table\s+(t\w+)', re.IGNORECASE | re.MULTILINE)
pat_sql_table = re.compile(
    r'(from|update|delete\s+from)\s+([a-z0-9_]+)',
    re.IGNORECASE
)

def extract_tables_from_txt(file_path):
    table_set = set()
    with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
        content = f.read()

    decl_tables = pat_table_decl.findall(content)
    for tbl in decl_tables:
        table_set.add(tbl.lower())

    sql_raw = pat_sql_table.findall(content)
    for _, short_name in sql_raw:
        short_name = short_name.lower()
        if not short_name.startswith("t"):
            full_name = "t" + short_name
            table_set.add(full_name)
        else:
            table_set.add(short_name)
    return sorted(list(table_set))


def main():
    session_table_map = {}
    all_tables = set()

    for fname in os.listdir(SRC_FOLDER):
        if fname.lower().endswith(".txt"):
            fpath = os.path.join(SRC_FOLDER, fname)
            tbl_list = extract_tables_from_txt(fpath)
            session_table_map[fname] = tbl_list
            for t in tbl_list:
                all_tables.add(t)

    with open(OUTPUT_CSV, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(["sessionファイル名", "完全テーブル名(t付き)", "確認欄", "正式テーブル説明"])
        for sess_name, tbls in session_table_map.items():
            for tbl in tbls:
                writer.writerow([sess_name, tbl, "", ""])

    mapping = {tbl: "テーブル説明未登録" for tbl in sorted(all_tables)}
    with open(MAPPING_JSON, "w", encoding="utf-8") as f:
        json.dump(mapping, f, ensure_ascii=False, indent=2)

    print("=== 実行完了 ===")
    print(f"解析txt数：{len(session_table_map)}")
    print(f"抽出総テーブル数：{len(all_tables)}")
    print(f"出力CSV：{OUTPUT_CSV}")
    print(f"出力mapping：{MAPPING_JSON}")

if __name__ == "__main__":
    main()
