# Baan 4GL 数据流分析Demo使用说明
这是一套完整可运行的端到端示例包，你可以直接替换成自己的4GL源码使用。

## 目录说明
```
baan-agent-demo/
├── source/pkapur/          # 把你自己的4GL文件替换这里的示例文件
├── output/                 # AI生成的报告和流程图会输出到这里
│   ├── baan_dataflow_report.md
│   └── diagrams/flow.mmd
└── .github/skills/baan-4gl-dataflow-analyzer/
    └── SKILL.md            # AI分析的规则文件，不需要改
```

## 使用步骤
1. 把你自己的4GL源码文件，替换 `source/pkapur/` 下面的4个示例文件
2. 用VS Code打开整个baan-agent-demo文件夹，启动GitHub Copilot Agent
3. 直接发送指令：
```
调用技能 baan-4gl-dataflow-analyzer，读取source目录下全部4GL源码，按照SKILL.md规则生成数据流分析报告。
```
4. 运行完成后，打开 `output/baan_dataflow_report.md` 就能看到生成的完整报告。

## 这个Demo已经演示的效果
- 从4个真实Baan风格4GL源码（申请→审批→发单→收货）
- 自动识别表CRUD操作、业务规则、字段流转
- 生成横向LR精简流程图（只画主干，不堆细碎表）
- 报告带可信度标签（CONFIRMED/INFERRED/UNKNOWN）
- 输出格式和你给的日文样例结构完全对齐
