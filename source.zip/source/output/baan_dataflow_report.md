# データフロー分析報告書: kapur2205m000

## 1. 基本情報

| 項目 | 値 |
|------|-----|
| **対象Session** | `kapur2205m000`（ヘッダー機能: Purchase information file making (Each factory)）[CONFIRMED: `source/pkapur/kapur2205m000.txt` 行2-5] |
| **プログラムID** | `kapur2205`（`#ident`）[CONFIRMED: `source/pkapur/kapur2205m000.txt` 行14] |
| **パッケージ** | `pkapur`（ソース格納ディレクトリ名からの推定）[INFERRED: package宣言はソース内で未確認] |
| **最終出力** | `inp.dir` と `inp.file` で指定されるタブ区切りファイル [CONFIRMED: 行20-21、97-101、132-138] |
| **分析実施日** | 2026-10-23 |
| **分析深度** | 4 レベル（`cprrp110` → `kapur201` → `kapur202` → 出力ファイル）[CONFIRMED: 各プログラムの読み書き。最大許容深度はソース内で未定義] |

## 2. 全体フロー図

```mermaid
graph TD
    A["<b>cprrp110</b><br/>(Planned Order Lines)<br/>【入力】"]
    B["<b>kapur2201m000</b><br/>(Generate Planned Subcontracting Orders)<br/>【セッション】"]
    C["<b>kapur201</b><br/>(Planned Subcontracting Data)<br/>【中間テーブル】"]
    D["<b>kapur2202m000</b><br/>(Generate Purchase information)<br/>【セッション】"]
    E["<b>kapur2204m000</b><br/>(Generate Purchase information)<br/>【セッション】"]
    F["<b>kapur202</b><br/>(Purchase information)<br/>【出力テーブル】"]
    G["<b>kapur2205m000</b><br/>(Purchase information file making)<br/>【対象セッション】"]
    H["<b>タブ区切りファイル</b><br/>(購買情報レコード)<br/>【最終出力】"]

    A -->|"外注計画行 SELECT"| B
    B -->|"外注計画データ INSERT"| C
    A -->|"購買計画行 SELECT"| D
    A -->|"購買計画行 SELECT"| E
    C -->|"購買情報生成"| D
    C -->|"取引先範囲で集計"| E
    D -->|"INSERT / UPDATE"| F
    E -->|"INSERT / UPDATE"| F
    F -->|"対象範囲 SELECT"| G
    G -->|"タブ区切り出力"| H

    style A fill:#e1f5ff
    style C fill:#f3e5f5
    style F fill:#fff9c4
    style H fill:#fff3e0
```

図のうち `kapur2205m000` に直接該当する読取は `kapur202` からのSELECTとファイル出力です（CONFIRMED: `kapur2205m000.txt` 行115-138）。上流の `kapur201` / `kapur202` 生成経路は、同じソース範囲で確認できた書込コードを示します（CONFIRMED: `kapur2201m000.txt` 行254-268、625-660、`kapur2202m000.txt` 行244-321、453-646、`kapur2204m000.txt` 行464-468、590-603、779-1080）。図はデータ依存を示し、スケジュール上の実行順序を保証しません（UNKNOWN）。

## 3. テーブルアクセス一覧

### 対象Session概要

- **簡略概要：** `kapur202` の指定キー範囲から品目、日付、数量、取引先を読み、会社コードを加えてタブ区切りレコードを出力します（CONFIRMED: 行115-138）。
- **詳細概要：** 最小・最大の取引先、品目、日付を設定し、`kapur202._index1` の範囲検索を行います。納期 `olfd` が0でないレコードのみ出力します。出力日付は `num.to.date$` で整形されます（CONFIRMED: 行67-72、115-138）。
- **ソースコード：** [kapur2205m000.txt](../source/pkapur/kapur2205m000.txt)

### 使用テーブル一覧

| テーブル名 | 説明 | 操作 |
|---|---|---|
| `kapur202` | Purchase information | SELECT（4フィールド、`_index1` 範囲指定） |

### 処理詳細・CRUD根拠

| テーブル名 | 操作 | フィールド | WHERE / 索引条件 | 根拠・信頼度 |
|---|---|---|---|---|
| `kapur202` | SELECT | `item, olfd, oqan, bpid` | `_index1 inrange {min.bpid, min.item, min.olfd} and {max.bpid, max.item, max.olfd}`。`min.*` / `max.*` は各ドメインに `set.min` / `set.max` を適用した範囲値。 | 行115-126、CONFIRMED |

このSession内で `db.insert`、`db.update`、`db.delete` は確認できません。対象Sessionがデータベースに書き込む処理はなく、ファイル出力が最終処理です（CONFIRMED: 全ソースのDB操作記述と行115-138）。

### カラム間マッピング

| 出力順 | ソースフィールド | 出力値 | 変換 |
|---:|---|---|---|
| 1 | `kapur202.item` | 品目 | `strip$` で前後空白除去（行132）[CONFIRMED] |
| 2 | `kapur202.olfd` | 納期 | `num.to.date$(kapur202.olfd, 2)`（行133）[CONFIRMED] |
| 3 | `kapur202.oqan` | 数量 | `str$` 後に `strip$`（行134）[CONFIRMED] |
| 4 | `kapur202.bpid` | 取引先 | `str$` 後に `strip$`（行135）[CONFIRMED] |
| 5 | `company.code` | 会社コード | `get.compnr()` で取得後、`str$` に変換（行87、136）[CONFIRMED] |

各値の間はタブ文字です（`tab` 定義: 行33、連結: 行132-136）。`seq.puts` が正常終了した場合に出力件数を加算します（行138-139）。CSV引用符、ヘッダー行、文字コード、改行形式はソースから確定できません（UNKNOWN: ファイル仕様定義なし）。

### 排他ロック・ファイル処理

| 処理 | 根拠 | 信頼度 |
|---|---|---|
| 入力必須チェック | `inp.dir` / `inp.file` が空の場合、それぞれ `kapur22050001` / `kapur22050002` を設定。行51-61 | CONFIRMED |
| 排他ロック取得 | `appl.set(session.id & str$(company.code), appl.excl)`。`session.id = prog.name$`、会社コードは `get.compnr()`。行87-89 | CONFIRMED |
| 出力先決定・オープン | `inp.dir` と `inp.file` を連結し `seq.open(filepath,"wt")`。行95-105 | CONFIRMED |
| レコード書込 | `seq.puts(write.buf,file.pointer)`。失敗時はエラー通知、ファイルクローズ、ロック解放を実行。行138-146 | CONFIRMED |
| ファイルクローズ | `seq.close(file.pointer)`。失敗時に `kapur22050006`。行170-175 | CONFIRMED |
| 排他ロック解放 | `appl.delete(session.id & str$(company.code))`。失敗時に `kapur22050007`。行161-166 | CONFIRMED |
| 完了通知 | `mess("kapur22050008",1,count)`。行79 | CONFIRMED |

### エラーハンドリング表

| エラーコード | メッセージ用途 | 対応 |
|---|---|---|
| `kapur22050001` | 出力ディレクトリ未入力 | 入力エラーを設定（行51-54） |
| `kapur22050002` | 出力ファイル名未入力 | 入力エラーを設定（行57-60） |
| `kapur22050003` | 排他ロック取得失敗 | ジョブエラーを設定して終了（行88-91） |
| `kapur22050004` | 出力ファイルオープン失敗 | ジョブエラー、ロック解放後に終了（行102-107） |
| `kapur22050005` | レコード出力失敗 | ジョブエラー、ファイルクローズとロック解放後に終了（行138-146） |
| `kapur22050006` | ファイルクローズ失敗 | エラーフラグを設定（行170-175） |
| `kapur22050007` | 排他ロック解放失敗 | エラーフラグを設定（行161-166） |
| `kapur22050008` | 出力件数付き完了通知 | 正常処理後に件数を通知（行79） |

メッセージのローカライズ済み表示文言はこのソースに含まれず、番号から先の文章は特定できません（UNKNOWN: message resource未提供）。

## 5. データ完全性リスク評価

| リスク | 評価・根拠 | 信頼度 |
|---|---|---|
| 出力対象範囲 | `_index1` の複合範囲に加え、`olfd <> 0` の行のみファイル出力。範囲値の実運用設定はこのSessionのコードだけでは確定できない（行115-126）。 | CONFIRMED / 実設定 UNKNOWN |
| フィールド完全性 | SELECT対象は `item, olfd, oqan, bpid` の4列。会社コードはDB列ではなく実行時に取得した値を追加する（行115、132-136）。テーブル定義がないため列型・NULL可否・キー制約は不明。 | CONFIRMED / `[UNKNOWN: テーブル定義なし]` |
| 出力レコード構造 | 5値をタブ区切りで連結する。引用符やエスケープ処理は確認できず、下流が区切り文字を含む値をどう扱うかは不明（行132-138）。 | CONFIRMED / 下流互換性 UNKNOWN |
| 無効日付の扱い | `olfd = 0` を出力対象から除外する（行124-126）。除外件数を個別に記録する処理は確認できない。 | CONFIRMED |
| 共有元テーブル | `kapur202` は `kapur2202m000` と `kapur2204m000` の双方からINSERT/UPDATEされる。`kapur2202m000` は処理開始時にテーブルを全件クリアし、`kapur2204m000` には同じクリア処理がない（2202 行907、954、2204 行794-1080）。出力実行中の同時更新によるスナップショット一貫性は本Sessionのコードからは確認できない。 | CONFIRMED / 分離レベル UNKNOWN |
| 排他保護範囲 | `kapur2205m000` は自身のSession IDと会社コードによるロックを取得するが、生成Sessionと同一ロックキーを使うかはソースから確認できない（行87-89、生成Sessionのロック処理との比較）。 | CONFIRMED / 相互排他 UNKNOWN |
| 出力成功判定 | レコード書込、ファイルクローズ、ロック解放の失敗経路は存在する。一方、出力ファイルの原子的置換や失敗時の部分ファイル削除は確認できない（行100-107、138-146、149-175）。 | CONFIRMED / API詳細 UNKNOWN |

複数源分析章は対象Sessionがテーブルを書き込まないため省略しました。上表では入力テーブルの複数書込元をデータ完全性リスクとして記録しています。`kapur2202m000` / `kapur2204m000` の並列実行可否、実行順序制約、出力時の一貫性保証は、提示された4GLコードだけでは確定できません（UNKNOWN）。

分析完了時刻: 2026-10-23 | ステータス: ✅完了
