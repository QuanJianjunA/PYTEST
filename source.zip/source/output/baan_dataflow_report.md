# データフロー分析報告書（再分析）

## 1. 基本情報

### 分析対象プログラム一覧

`source/` を再走査し、以下4ファイルをそれぞれ全文読み込みました。4ファイルとも読み込み成功です。ソースヘッダーには明示的な `Description:` フィールドがないため、session機能はヘッダーのプログラム名・機能コメントに基づいて記載しています。[UNKNOWN: 正式なsession定義/API定義なし]

| ソースファイル | session名 | ヘッダーに記載された機能 | 判定 |
|---|---|---|---|
| `source/pkapur/kapur2201m000.txt` | `kapur2201m000`（ヘッダー短縮名 `kapur2201`） | Generate Planned Subcontracting Orders（外注計画オーダー生成） | CONFIRMED（行2-10） |
| `source/pkapur/kapur2202m000.txt` | `kapur2202m000`（ヘッダー短縮名 `kapur2202`） | Generate Purchase information（購買情報生成） | CONFIRMED（行2-7） |
| `source/pkapur/kapur2204m000.txt` | `kapur2204m000`（ヘッダー短縮名 `kapur2204`） | Generate Purchase information（購買情報生成。取引先範囲・金額チェック等を追加） | CONFIRMED（行2-7、行424-484、行590-623、行739-1080） |
| `source/pkapur/kapur2205m000.txt` | `kapur2205m000`（ヘッダー短縮名 `kapur2205`） | Purchase information file making (Each factory)（工場別購買情報ファイル作成） | CONFIRMED（行2-7） |

### 出力ファイル

- `output/baan_dataflow_report.md`
- `output/diagrams/flow.mmd`

### 分析実施日

2026-10-20（実行環境の日付）

## 2. データフロー全体図

以下はソースで確認できた主幹のみを表示します。`kapur2204` は `kapur201` と購買計画行を入力として `kapur202` / `kapur212` を生成・更新しますが、`kapur2202` から `kapur2204` への直接プログラム呼び出しは確認できません。`kapur2204` の `out.file` はエラー記録にも使われ、購買情報のタブ区切りファイル出力は `kapur2205` で確認できます。

```mermaid
graph TD
    A["<b>cprrp110</b><br/>(計画オーダー行)<br/>【入力】"]
    B["<b>kapur2201m000</b><br/>(外注計画オーダー生成)<br/>【セッション】"]
    C["<b>kapur201</b><br/>(計画外注データ)<br/>【中間データ】"]
    D["<b>kapur2202m000</b><br/>(購買情報生成)<br/>【セッション】"]
    E["<b>kapur202</b><br/>(購買情報)<br/>【出力テーブル】"]
    F["<b>kapur212</b><br/>(次回内示範囲)<br/>【出力テーブル】"]
    G["<b>kapur2204m000</b><br/>(購買情報生成・条件チェック)<br/>【セッション】"]
    H["<b>kapur2205m000</b><br/>(工場別購買情報ファイル作成)<br/>【セッション】"]
    I["<b>購買情報ファイル</b><br/>(タブ区切りレコード)<br/>【最終出力】"]

    A -->|"SFC計画行を抽出"| B
    B -->|"外注計画データ INSERT"| C
    A -->|"購買計画行を抽出"| D
    C -->|"外注計画データを集計"| D
    C -->|"外注計画データを参照"| G
    A -->|"購買計画行・取引先範囲を抽出"| G
    D -->|"購買情報 INSERT / UPDATE"| E
    D -->|"内示範囲 INSERT / UPDATE"| F
    G -->|"購買情報 INSERT / UPDATE"| E
    G -->|"内示範囲 INSERT / UPDATE"| F
    E -->|"対象範囲 SELECT"| H
    H -->|"タブ区切り出力"| I

    style A fill:#e1f5ff
    style C fill:#f3e5f5
    style E fill:#f3e5f5
    style F fill:#f3e5f5
    style I fill:#fff3e0
```

判定：各矢印は該当ソースの読み書きで確認できます（CONFIRMED）。`kapur202` から `kapur2205` への参照は `kapur2205` のSELECTにより確認できます（CONFIRMED）。この図は直接のテーブルCRUDを示すもので、実行順序やジョブスケジュールまでは証明しません（UNKNOWN）。

矢印ごとのコード根拠：

| 矢印 | 根拠 |
|---|---|
| `cprrp110` → `kapur2201` → `kapur201` | SELECT行254-268、INSERT行642-659（CONFIRMED） |
| `cprrp110` / `kapur201` → `kapur2202` | `cprrp110` SELECT行310-321、`kapur201` SELECT行244-246・集計行247-309（CONFIRMED） |
| `cprrp110` / `kapur201` → `kapur2204` | `kapur201` SELECT行464-468・集計行487-588、`cprrp110` SELECT行590-598（CONFIRMED） |
| `kapur2202` → `kapur202` / `kapur212` | `kapur202` INSERT/UPDATE行453-493・546-584、`kapur212` INSERT/UPDATE行615-646（CONFIRMED） |
| `kapur2204` → `kapur202` / `kapur212` | `kapur202` INSERT/UPDATE行779-828・889-936、`kapur212` INSERT/UPDATE行976-1009・1047-1080（CONFIRMED） |
| `kapur202` → `kapur2205` → ファイル | SELECT行115-125、レコード生成・出力行128-143（CONFIRMED） |

## 3. 各テーブルCRUD詳細

表記：SQL中の `kapurXXX` とテーブルハンドルの `tkapurXXX` は、ソースで対応して使用される同一テーブルを指すものとして併記します。テーブル定義がソース内にないため、`*` 選択の実フィールド一覧、索引定義、および各フィールドの物理型・業務上の意味は確定できません。[UNKNOWN: テーブル定義なし]。`SELECT *` は取得フィールドを省略せず `全フィールド（ソース上は *）` と記載します。

### 3.1 `kapur2201m000` — Generate Planned Subcontracting Orders

| テーブル | CRUD | フィールド | WHERE / 選択条件 | 根拠・信頼度 |
|---|---|---|---|---|
| `cprrp110` | SELECT | `*`（全フィールド） | `_index7` の範囲が `{cprpd000.aplc,tckoor.cp.sfc}` から同じキーまで。`cmba refers to cprrp100` で計画ヘッダーを参照。 | 行254-268、CONFIRMED。索引キーの業務意味は [UNKNOWN: 索引定義なし] |
| `cprrp100` | SELECT（結合） | `cplb` | `cprrp110.cmba refers to cprrp100`。主問合せのヘッダー参照。 | 行254-267、CONFIRMED |
| `tcibd001` | SELECT | `item, kitm, citg, dsca, umer` | `_index1 = {tc.item}` | 行299-304、CONFIRMED |
| `tirou101` | SELECT | `mitm, opro, stor, strc` | `_index1 = {tc.item,tirou000.dfrt}` | 行309-314、CONFIRMED |
| `tcibd007` | SELECT | `item, ltcp` | `_index1 = {tc.item}`。`ltcp = 0` またはレコードなしはエラー扱い。 | 行323-331、CONFIRMED |
| `kapur200` | SELECT | `*` | `_index1 = {tcibd001.citg}`、最大1行。 | 行354-360、CONFIRMED。全フィールド [UNKNOWN: テーブル定義なし] |
| `tipcs020` | SELECT | `cprj, cfdt` | `_index1 = {tmp.cprj}`、最大1行。`tmp.cprj` は `tcibd001.item(1;9)` から作成。 | 行365-379、CONFIRMED |
| `tirou102` | SELECT | `mitm, opro, opno, tano, cwoc, indt, seqn, exdt`（ソースでは `indt` を2回指定） | `_index3 = {tmp.item,tmp.strc}`。有効日を `check.date` と比較し、作業区分・外注先等も判定。 | 行387-419、CONFIRMED |
| `tirou001` | SELECT（結合） | `kowc, bpid` | `tirou102.cwoc refers to tirou001`。抽出後 `kowc = tckowc.subcontracting` 等を判定。 | 行387-419、CONFIRMED |
| `tipcs020` | SELECT | `cpcc` | `_index1 = {i.proj}` | 行584-589、CONFIRMED |
| `tipcs026` | SELECT | `mprj`（出力先 `o.main.cprj`） | `_index2 = {i.sub.cprj}`、最大1行 | 行597-603、CONFIRMED |
| `ticpr160` | SELECT | `*` | `_index1 = {i.proj,i.calc.code,i.bpid,i.tano}`。プロジェクト別・標準レートを段階的に検索。 | 行613-619、CONFIRMED。全フィールド [UNKNOWN: テーブル定義なし] |
| `tkapur201` | DELETE相当（全件クリア） | 全行 | `db.clear.table(tkapur201, WITH.ROLLBACK)`。WHEREなし。 | 行854-888、CONFIRMED。クリアAPIの厳密なトランザクション仕様は [UNKNOWN: API定義なし] |
| `tkapur201` | INSERT | `orno, pono, opno, seqn, mitm, tano, cwoc, bpid, sitm, olfd, cplb, oqan, citg, dscm, umer, crdt` | 有効な外注工程を対象。`mitm` は条件によりサブ組立品番に差替え。 | 行625-660、CONFIRMED |
| `karpd101` | SELECT | `btdt` | `_index1` 順の最大1行相当。 | 行837-850、CONFIRMED |
| `kacom200` | SELECT | `seid, kubn, cnts` | `_index1 = {prog.name$,"00001"}` | 行911-921、CONFIRMED |
| `kaoes118` | SELECT | `sitm, mitm, exin, sbcd` | `_index3 = {wk.sitm}`。ヒット時に出力レコードの `kapur201.mitm` を組み替える。 | 行925-939、CONFIRMED |
| `kapis003` | SELECT | `*` | `_index1 = {1}` | 行941-951、CONFIRMED。全フィールド [UNKNOWN: テーブル定義なし] |
| `kapis601` | SELECT | `hitm, item, tkbn` | `_index2 = {wk.item}` | 行965-969、CONFIRMED |
| `kacom200` | SELECT | `*` | `_index1 = {prog.name$,"99999",kapis601.tkbn}` | 行971-976、CONFIRMED。全フィールド [UNKNOWN: テーブル定義なし] |
| `kaglb050` | SELECT | `eitm, pbon` | `_index1 = {wk.item}` | 行980-984、CONFIRMED |
| `kacom200` | SELECT | `*` | `_index1 = {prog.name$,"99999",kaglb050.pbon}` | 行986-991、CONFIRMED。全フィールド [UNKNOWN: テーブル定義なし] |

ファイル出力：外注工程エラーを `fp2` に出力し、原価エラーを `fp1` に出力します。レコード連結は行684-703、行718-743、行761-787、実際の `seq.puts` は行702、742、785です（CONFIRMED）。ファイルの拡張子・CSV形式は当該コードから確認できません（UNKNOWN）。

### 3.2 `kapur2202m000` — Generate Purchase information

| テーブル | CRUD | フィールド | WHERE / 選択条件 | 根拠・信頼度 |
|---|---|---|---|---|
| `kapur201` | SELECT | `*` | WHEREなし。`_index2` 順に走査し、`bpid, mitm, olfd` 単位で数量を集計。 | 行244-246、行247-309、CONFIRMED。集計キーは行247-309 |
| `cprrp110` | SELECT | `*` | `_index7` の範囲が `{cprpd000.aplc,tckoor.cp.pur}` から同じキーまで。 | 行310-321、CONFIRMED。索引定義は [UNKNOWN: 索引定義なし] |
| `kapur202` | SELECT FOR UPDATE | `*` | `_index1 = {old.bpid,tc.item,old.olfd1}` | 行453-455、CONFIRMED。フィールド定義は [UNKNOWN: テーブル定義なし] |
| `tkapur202` | UPDATE | `oqan, cplb, etdt` | 上記SFC購買情報キーの既存行。数量加算し、条件により計画バッチ・終了日を更新。 | 行459-465、CONFIRMED |
| `tkapur202` | INSERT | `bpid, item, revi, dsca, sitm, dscm, olfd, yrpt, citg, cplb, oqan, crdt, koor, nopl, etdt` | 上記SFC集計キーで既存行がない場合。 | 行473-493、CONFIRMED |
| `kapur202` | SELECT FOR UPDATE | `*` | `_index1 = {old.suno,tc.item,old.olfd2}` | 行546-548、CONFIRMED |
| `tkapur202` | UPDATE | `oqan, cplb, etdt` | 上記購買計画キーの既存行。数量加算。 | 行550-556、CONFIRMED |
| `tkapur202` | INSERT | `bpid, item, revi, dsca, sitm, dscm, olfd, yrpt, citg, cplb, oqan, crdt, koor, nopl, etdt` | 上記購買計画キーで既存行がない場合。`sitm,dscm` は空文字として設定。 | 行562-584、CONFIRMED |
| `kapur212` | SELECT FOR UPDATE | `*` | `_index1 = {old.suno,tc.item}` | 行615-617、CONFIRMED |
| `tkapur212` | UPDATE | `prdt, endt, cplb, stdt` | 既存行について、計画バッチが異なり、かつ新しい終了日が既存終了日より前の場合。 | 行620-629、CONFIRMED |
| `tkapur212` | INSERT | `bpid, item, prdt, endt, cplb, stdt` | 上記キーの既存行がない場合。 | 行634-646、CONFIRMED |
| `tcccp020` | SELECT | `ccal, year, date, yrpt, sern` | `_index3 = {o.calender,yearno,i.olfd}` | 行736-744、CONFIRMED |
| `kadli006` | SELECT | `*` | `_index2 = {i.citg}`。`cikb` がbulk区分かを判定。 | 行752-764、CONFIRMED。全フィールド [UNKNOWN: テーブル定義なし] |
| `tcibd007` | SELECT | `*` | `_index1 = {tc.item}`。`ltcp = 0` またはレコードなしは原価エラー。 | 行777-791、CONFIRMED。全フィールド [UNKNOWN: テーブル定義なし] |
| `karpd001` | SELECT | `*` | `_index1` 範囲 `{cprrp100.cplb,karpd101.btdt}` ～ `{cprrp100.cplb,prdt.max}`、かつ `endt <> 0`、最大1行。 | 行805-821、CONFIRMED |
| `cprrp100` | SELECT | `plnc, type, orno, cplb` | `_index1 = {i.plnc,i.tckoor,i.orno}` | 行832-844、CONFIRMED |
| `tcibd001` | SELECT | `item, kitm, citg, dsca, umer, cwar` | `_index1 = {i.item}` | 行849-862、CONFIRMED |
| `karpd101` | SELECT | `btdt` | `_index1` 順の最大1行相当。 | 行867-879、CONFIRMED |
| `tkapur202` | DELETE相当（全件クリア） | 全行 | `db.clear.table(tkapur202, WITH.ROLLBACK)`。WHEREなし。 | 行882-914、CONFIRMED。API仕様は [UNKNOWN: API定義なし] |
| `tkapur212` | DELETE相当（全件クリア） | 全行 | `db.clear.table(tkapur212, WITH.ROLLBACK)`。WHEREなし。 | 行929-961、CONFIRMED。API仕様は [UNKNOWN: API定義なし] |
| `karpd001` | SELECT | `cplb, prdt, endt, etdt` | `_index1` 範囲 `{old.cplb,karpd101.btdt}` ～ `{old.cplb,prdt.max}`、かつ `endt <> 0`、最大1行。 | 行1014-1032、CONFIRMED |
| `tcmcs003` | SELECT | `*` | `_index1 = {tcibd001.cwar}` | 行1036-1044、CONFIRMED。全フィールド [UNKNOWN: テーブル定義なし] |
| `cprpd400` | SELECT | `plnc, plfd` | `_index1 = {cprpd000.aplc}` | 行1048-1057、CONFIRMED |

`tiedm.dll0001.search.revision(...)` による改訂取得呼び出しは確認できます（行432-439、行521-525）が、DLL内部のテーブル・フィールドCRUDはこのソースだけでは特定できません。[UNKNOWN: API実装なし]

### 3.3 `kapur2204m000` — Generate Purchase information

| テーブル | CRUD | フィールド | WHERE / 選択条件 | 根拠・信頼度 |
|---|---|---|---|---|
| `kacom200` | SELECT | `seid, kubn, cnts` | `_index1 = {prog.name$,"00002"}`、`"00003"`、`"00004"`（基準日・数量桁・金額桁のパラメータ）。 | 行266-296、CONFIRMED |
| `kacom200` | SELECT | `seid, kubn, cnts` | `_index1 = {wk.seid,wk.kubn,wk.cnts}`、`wk.kubn="00001"`、`wk.cnts="1"`。 | 行434-447、CONFIRMED |
| `kapur201` | SELECT | `*` | `_index2` の範囲 `{bpid.f}` ～ `{bpid.t}`。 | 行464-468、CONFIRMED。全フィールド [UNKNOWN: テーブル定義なし] |
| `kapcg060` | SELECT | `bpid, oryn` | `_index2 = {tcyesno.no,kapur201.bpid}`。 | 行470-474、CONFIRMED |
| `cprrp100` | SELECT | `dwar, plnc, type, orno`（出力先別名 `wk.*`） | `_index1 = {cprpd000.aplc,tckoor.cp.sfc,kapur201.orno}` | 行476-480、CONFIRMED |
| `kapcg061` | SELECT | `cwar, bpid` | `_index1 = {kapcg060.bpid,wk.dwar}` | 行482-486、CONFIRMED |
| `cprrp110` | SELECT | `plnc, koor, litm, suno, olfd, orno, pono, oqan` | `_index7` 範囲 `{cprpd000.aplc,tckoor.cp.pur,空品目,bpid.f}` ～ `{cprpd000.aplc,tckoor.cp.pur,上限品目,bpid.t}` | 行590-598、CONFIRMED。索引定義は [UNKNOWN: 索引定義なし] |
| `kapcg060` | SELECT | `bpid, oryn` | `_index1 = {cprrp110.suno}`、かつ `oryn = tcyesno.no` | 行607-611、CONFIRMED |
| `cprrp100` | SELECT | `dwar, plnc, type, orno`（出力先別名 `wk.*`） | `_index1 = {cprrp110.plnc,cprrp110.koor,cprrp110.orno}` | 行614-618、CONFIRMED |
| `kapcg061` | SELECT | `cwar, bpid` | `_index1 = {kapcg060.bpid,wk.dwar}` | 行620-625、CONFIRMED |
| `tcibd001`（別名 `altcibd001`） | SELECT | `item, eitm, umer` | `_index1 = {wk.tc.item}`。工学品目該当時に改訂検索を呼ぶ。 | 行760-767、CONFIRMED |
| `kapur202` | SELECT FOR UPDATE | `*` | `_index1 = {old.bpid,tc.item,old.olfd1}` | 行779-781、CONFIRMED |
| `tkapur202` | UPDATE | `oqan, cplb, etdt` | 上記外注情報キーの既存行。 | 行784-795、CONFIRMED |
| `tkapur202` | INSERT | `bpid, item, revi, dsca, sitm, dscm, olfd, yrpt, citg, cplb, oqan, crdt, koor, nopl, etdt` | 上記外注情報キーで既存行がない場合。 | 行800-828、CONFIRMED |
| `tcibd001`（別名 `altcibd001`） | SELECT | `item, eitm, umer` | `_index1 = {wk.tc.item}`。 | 行866-875、CONFIRMED |
| `kapur202` | SELECT FOR UPDATE | `*` | `_index1 = {old.suno,tc.item,old.olfd2}` | 行889-891、CONFIRMED |
| `tkapur202` | UPDATE | `oqan, cplb, etdt` | 上記購買情報キーの既存行。 | 行895-903、CONFIRMED |
| `tkapur202` | INSERT | `bpid, item, revi, dsca, sitm, dscm, olfd, yrpt, citg, cplb, oqan, crdt, koor, nopl, etdt` | 上記購買情報キーで既存行がない場合。`sitm,dscm` は空文字。 | 行908-936、CONFIRMED |
| `kapur212` | SELECT FOR UPDATE | `*` | `_index1 = {old.bpid,tc.item}`（外注分）。 | 行976-978、CONFIRMED |
| `tkapur212` | UPDATE | `prdt, endt, cplb, stdt` | 既存行で `kapur201.cplb <> kapur212.cplb`、かつ新しい終了日が既存終了日より前。 | 行982-990、CONFIRMED |
| `tkapur212` | INSERT | `bpid, item, prdt, endt, cplb, stdt` | 上記キーの既存行がない場合。 | 行1000-1009、CONFIRMED |
| `kapur212` | SELECT FOR UPDATE | `*` | `_index1 = {old.suno,tc.item}`（購買計画分）。 | 行1047-1049、CONFIRMED |
| `tkapur212` | UPDATE | `prdt, endt, cplb, stdt` | 既存行で `cprrp100.cplb <> kapur212.cplb`、かつ新しい終了日が既存終了日より前。 | 行1052-1061、CONFIRMED |
| `tkapur212` | INSERT | `bpid, item, prdt, endt, cplb, stdt` | 上記キーの既存行がない場合。 | 行1071-1080、CONFIRMED |
| `tcccp020` | SELECT | `ccal, year, date, yrpt, sern` | `_index3 = {o.calender,yearno,i.olfd}` | 行1182-1190、CONFIRMED |
| `kadli006` | SELECT | `*` | `_index2 = {i.citg}` | 行1198-1210、CONFIRMED。全フィールド [UNKNOWN: テーブル定義なし] |
| `tcibd007` | SELECT | `item, ltcp` | `_index1 = {tc.item}`。`ltcp = 0` またはレコードなしを原価エラーとする。 | 行1220-1231、CONFIRMED |
| `cprrp100` | SELECT | `plnc, type, orno, cplb` | `_index1 = {i.plnc,i.tckoor,i.orno}` | 行1277-1286、CONFIRMED |
| `tcibd001` | SELECT | `item, kitm, citg, dsca, umer, cwar` | `_index1 = {i.item}` | 行1290-1301、CONFIRMED |
| `karpd101` | SELECT | `btdt` | `_index1` 順の最大1行相当。 | 行1308-1320、CONFIRMED |
| `karpd001` | SELECT | `*` | `_index1` 範囲 `{cprrp100.cplb,karpd101.btdt}` ～ `{cprrp100.cplb,prdt.max}`、`endt <> 0`、最大1行。 | 行1248-1267、CONFIRMED |
| `karpd001` | SELECT | `cplb, prdt, endt, etdt, pfdt, stdt` | `_index1` 範囲 `{kapur201.cplb,karpd101.btdt}` ～ `{kapur201.cplb,prdt.max}`、`endt <> 0`。 | 行1371-1395、CONFIRMED |
| `tcmcs003` | SELECT | `*` | `_index1 = {tcibd001.cwar}` | 行1405-1413、CONFIRMED。全フィールド [UNKNOWN: テーブル定義なし] |
| `cprpd400` | SELECT | `plnc, plfd` | `_index1 = {cprpd000.aplc}` | 行1417-1426、CONFIRMED |
| `kapis003` | SELECT | `*` | `_index1 = {1}` | 行1568-1578、CONFIRMED。全フィールド [UNKNOWN: テーブル定義なし] |
| `kapis601` | SELECT | `hitm, item, tkbn` | `_index2 = {wk.item}` | 行1592-1596、CONFIRMED |
| `kacom200` | SELECT | `*` | `_index1 = {prog.name$,"99999",kapis601.tkbn}` | 行1598-1603、CONFIRMED。全フィールド [UNKNOWN: テーブル定義なし] |
| `kaglb050` | SELECT | `eitm, pbon` | `_index1 = {wk.item}` | 行1607-1611、CONFIRMED |
| `kacom200` | SELECT | `*` | `_index1 = {prog.name$,"99999",kaglb050.pbon}` | 行1613-1618、CONFIRMED。全フィールド [UNKNOWN: テーブル定義なし] |
| `kapcg020` | SELECT | `*` | `_index1 = {kapur202.item,tirou000.dfrt,old.opno,old.seqn}`、`bpid = kapur202.bpid`、`efdt <= old.olfdutc1`、`exdt > old.olfdutc1 OR exdt = 0`、降順最大1行。 | 行1749-1761、CONFIRMED。全フィールド [UNKNOWN: テーブル定義なし] |
| `kapcg010` | SELECT | `*` | `_index5` を `{kapur202.item,tdpcg.pbor.stnd,kapur202.bpid,efdt.min}` ～ `{kapur202.item,tdpcg.pbor.stnd,kapur202.bpid,old.olfdutc2}` の範囲で検索し、`exdt > old.olfdutc2 OR exdt = 0`、降順最大1行。 | 行1794-1807、CONFIRMED。全フィールド [UNKNOWN: テーブル定義なし] |
| `kaoes021` | SELECT | `sbcd` | `_index1 = {w.item}` | 行1850-1856、CONFIRMED |
| `kacom200` | SELECT | `seid, kubn, cnts` | `_index1 = {prog.name$,"00005",w.bpid}`。対象外取引先の判定。 | 行1867-1874、CONFIRMED |

ファイル出力：`out.file` を開きます（行237-238）。購買金額・原価エラー行が `fp` に出力されます（行1111-1134）。オプションの `fp1` エラーログにはヘッダーとエラー記録を出力します（行1705-1732）。このコードでは購買情報全件の通常CSV出力は確認できず、行出力されるのはエラー関連の記録です（CONFIRMED: 出力呼び出し箇所、行1134・1705-1732）。CSV形式であるとの判断はできません（UNKNOWN）。

### 3.4 `kapur2205m000` — Purchase information file making (Each factory)

| テーブル | CRUD | フィールド | WHERE / 選択条件 | 根拠・信頼度 |
|---|---|---|---|---|
| `kapur202` | SELECT | `item, olfd, oqan, bpid` | `_index1` 範囲 `{min.bpid,min.item,min.olfd}` ～ `{max.bpid,max.item,max.olfd}`。選択後 `olfd <> 0` の行を出力。 | 行115-125、CONFIRMED |

出力は `filepath` を `"wt"` で開き（行98-105）、各レコードを `item, olfd（日付変換）, oqan, bpid, company.code` の順にタブ区切りで組み立て、`seq.puts` で書き込みます（行128-143）。CSVという拡張子・ヘッダー・エスケープ仕様はソースから確認できません。[UNKNOWN: ファイル形式定義なし]。

## 4. データの流れ系統

### Level 0：源入力テーブル

- `cprrp110` のSFC計画行を `kapur2201` が抽出します。抽出列は `cprrp110.*`、条件は `_index7` のSFC計画範囲、ヘッダーは `cprrp100` 参照です（CONFIRMED: `kapur2201` 行254-268）。
- `cprrp110` の購買計画行を `kapur2202` / `kapur2204` が読みます。`kapur2202` は購買計画種別の索引範囲（行310-321）、`kapur2204` はさらに取引先範囲を条件に含め、必要列のみ取得します（行590-598）。
- `kapur2201` は品目・原価・工程・外注先・プロジェクト等の参照データを照合します（CONFIRMED: 3.1のCRUD一覧）。参照データから業務上の制約・値の意味を確定することはできません。[UNKNOWN: テーブル定義なし]

### Level 1：中間データ（外注計画データ）

- `kapur2201` は事前に `tkapur201` を全件クリアし、計画オーダー行と有効な外注工程からフィールドを組み立ててINSERTします（CONFIRMED: `kapur2201` 行854-888、行625-660）。
- 主要な値の転記は `cprrp110.orno/pono/olfd/oqan`、工程 `tirou102.opno/seqn/tano/cwoc/indt/exdt`、取引先 `tirou001.bpid`、品目マスター `tcibd001.citg/dsca/umer`、計画ヘッダー `cprrp100.cplb` です（CONFIRMED: INSERT代入行642-659、工程・マスター取得行299-419）。フィールドの物理制約は不明です（UNKNOWN）。
- `kapur2202` と `kapur2204` はこの `kapur201` を読み、`bpid, mitm, olfd` 単位で `oqan` を集計します（CONFIRMED: `kapur2202` 行244-309、`kapur2204` 行464-468と行487-588）。
- 「承認」状態を示す更新・承認フィールドはこの4ファイルでは確認できません。したがって `kapur201` を承認済みテーブルとみなすのは推定できません。[UNKNOWN: 承認フロー定義なし]

### Level 2：購買情報・内示範囲

- `kapur2202` は `kapur201` の外注情報を集計し、`kapur202`（購買情報）にINSERTまたは数量等をUPDATEします。また `cprrp110` の購買計画からも同テーブルにINSERT/UPDATEします（CONFIRMED: `kapur2202` 行428-593）。
- `kapur2204` は取引先範囲・サブ組立倉庫条件などで対象を絞り、同じく `kapur202` をINSERT/UPDATEします（CONFIRMED: 行464-625、行739-936）。
- 両プログラムは `karpd001` 等から計画バッチ・期間情報を読み、`kapur212` をINSERT/UPDATEします（CONFIRMED: `kapur2202` 行597-650、`kapur2204` 行952-1086）。
- ここで確認されるのは購買情報・内示情報です。検収・在庫テーブルへの直接CRUDは本分析対象4ファイルのCRUD一覧にありません（INFERRED: 各ファイルのSQL/CUD箇所、`kapur2201` 行244-989、`kapur2202` 行221-1057、`kapur2204` 行424-1874、`kapur2205` 行79-178）。別プログラムで後続処理されるかは不明です（UNKNOWN）。

### Level 3：最終ファイル出力

- `kapur2205` は `kapur202` から `item, olfd, oqan, bpid` を範囲抽出し、`olfd <> 0` のレコードを会社コードとともにタブ区切りでファイル出力します（CONFIRMED: 行115-143）。
- `kapur2204` には別途エラー記録ファイル出力がありますが、通常の購買情報ファイル出力を行う根拠は見つかりません（CONFIRMED: `seq.puts` 行1134、1705-1732）。CSV拡張子や文字コード等の仕様は不明です（UNKNOWN）。

## 5. 業務ルール一覧

| プログラム | 条件 | 業務意味 | 信頼度 |
|---|---|---|---|
| `kapur2201` | `cprrp110` はSFC計画種別の索引範囲で走査する。 | 対象計画行から外注計画を作る。 | CONFIRMED（行254-268） |
| `kapur2201` | 工程の `indt <= check.date` かつ `exdt > check.date` または `exdt = 0`。 | 有効期間内の工程を対象候補とする。 | CONFIRMED（行405-419） |
| `kapur2201` | 初期日付は `cprrp110.olfd`。プロジェクトの `cfdt` が0ならバッチ日付の23:59:59、0以外なら `cfdt` を検査日とする。 | 工程有効期間を判定する日付を計画・プロジェクト情報から決める。 | CONFIRMED（行366-378、行837-846） |
| `kapur2201` | 外注工程がなく `sub.flg` が立たない場合、エラーコード3を設定しエラー記録する。 | 有効な外注工程が見つからない品目はエラー扱い。 | CONFIRMED（行421-435） |
| `kapur2201` | `tcibd007.ltcp = 0` または原価レコードなし。 | 標準原価未設定をエラーとする。 | CONFIRMED（行323-340） |
| `kapur2201` | 同一ベンダーで異なる作業番号の重複を検出。 | 重複外注先・工程候補をチェックする。 | CONFIRMED（行548-580）。「重複」の業務上の扱いは INFERRED |
| `kapur2201` | 外注レートはプロジェクト・計算コード・外注先・タスクで検索し、不成立時は関連メインプロジェクト、さらに標準レートへフォールバックする。 | 外注原価レートの検索優先順位。 | CONFIRMED（行500-568） |
| `kapur2201` | `kapur201` を生成前に `db.clear.table`。 | 実行時に既存中間データを全件クリアする。 | CONFIRMED（行854-888） |
| `kapur2202` | `kapur201` を走査し、同じ取引先・品目・日付の数量を加算。 | 外注計画データを日付・取引先・品目単位に集約する。 | CONFIRMED（行244-309） |
| `kapur2202` | 対象品目の `ltcp = 0` または原価データなし。 | 原価未設定はエラーファイルに記録し、当該集計をスキップ。 | CONFIRMED（行777-791、行350-384） |
| `kapur2202` | `suno` が空白。 | 取引先不備をエラー記録し、当該集計をスキップ。 | CONFIRMED（行383-397、行675-700） |
| `kapur2202` | 品目グループが `kadli.cikb.bulk`。 | Bulk品目として通常集計対象から外す。 | CONFIRMED（行752-764および行260-272）。業務名称はコメント・定数に基づく |
| `kapur2204` | 入力取引先範囲 `bpid.f` ～ `bpid.t` で `kapur201` と計画行を抽出。 | 画面指定範囲の取引先に限定する。 | CONFIRMED（行464-468、行590-598） |
| `kapur2204` | `kapcg060.oryn = no` と対応する倉庫 `kapcg061` が見つかると `skip.flg` を立て、行をスキップ。 | 特定の外注先・倉庫の組合せを対象外にする。 | CONFIRMED（行470-488、行607-628） |
| `kapur2204` | `check020()` / `check010()` は数量・金額・ゼロ円条件を検査し、エラーログへ出す。 | 購買情報の値をチェックし、条件によりエラー記録する。 | CONFIRMED（行1625-1691、行1744-1828） |
| `kapur2204` | 外注単価は `subr+jgrt`（取引先条件一致時はさらに `pdrt`）、購買単価は `ptpr+jgrt`（条件一致時はさらに `pdrt`）。単価×数量を小数2桁に丸め、設定上限と比較する。 | 外注・購買金額の桁あふれを検査する。 | CONFIRMED（行1759-1774、行1803-1818、上限設定行279-299） |
| `kapur2204` | 外注サブ組立品番でない場合、丸め後金額が0なら取引先除外設定を参照してエラー記録する。購買分も丸め後金額0を検査する。 | 対象取引先に対するゼロ円チェック。 | CONFIRMED（行1776-1783、行1819-1825、行1847-1875） |
| `kapur2204` | `check020/010` の戻り値を呼出側で無視する空の条件ブロックがあり、削除処理はコメントアウト。 | 検査結果が必ずしもINSERT/UPDATEを阻止しない。 | CONFIRMED（呼出し行790-796、行824-830、行898-904、行932-938。削除関数は行1829-1844でコメントアウト） |
| `kapur2204` | `check020/010` は `w.err.msg3` を出力しても戻り値判定は `w.err.msg1` または `w.err.msg2` のみ。 | ゼロ円エラー単独では関数戻り値がtrueにならない可能性がある。 | CONFIRMED（`msg3` ログ行1646/1680、戻り値判定行1651/1685） |
| `kapur2205` | `kapur202.olfd <> 0`。 | 日付が0でない購買情報だけを出力する。 | CONFIRMED（行121-125） |
| `kapur2205` | 選択範囲は取引先・品目・日付の最小値から最大値まで。 | 画面指定範囲に該当する購買情報をファイル化する。 | CONFIRMED（行115-119） |

## 6. 分析まとめ

1. **主な連鎖**：計画オーダー行 `cprrp110` → 外注計画データ `kapur201` → 購買情報 `kapur202` / 内示範囲 `kapur212` → `kapur2205` のタブ区切りファイル出力、というCRUD連鎖がソースで確認できます（CONFIRMED: 各プログラムの該当SQL/CUD行）。
2. **二つの購買情報生成セッション**：`kapur2202` と `kapur2204` は共に `kapur202` / `kapur212` を書きます（CONFIRMED: CRUD詳細）。両ソースの処理部には相互呼び出しが見当たりません（INFERRED: `kapur2202` 行221-421、`kapur2204` 行424-738）。実行順序は不明です（UNKNOWN）。
3. **全件クリアの注意**：`kapur2201` は `kapur201`、`kapur2202` は `kapur202` と `kapur212` を処理開始時に全件クリアします（CONFIRMED: `kapur2201` 呼出し行249・実装行854-888、`kapur2202` 呼出し行230-231・実装行882-914・929-961）。並行実行・再実行時の影響は重要ですが、ロック範囲や環境運用の仕様はこのソースだけでは確定できません（INFERRED）。
4. **検査と保存の差**：`kapur2204` の数量・金額検査はエラーを記録する一方、呼出元は戻り値を保存制御に使用しておらず、旧削除処理もコメントアウトされています。エラーがあってもレコードが保存され得る構造です（CONFIRMED: 業務ルール表の該当行）。
5. **出力形式**：購買情報のファイルレコード構造は `kapur2205` のみで確認でき、`item / 日付 / 数量 / 取引先 / 会社コード` のタブ区切りです。CSVであること、ヘッダー、文字コードは確認できません（CONFIRMED / UNKNOWN）。
6. **未確認事項**：テーブル定義・ドメイン仕様・外部DLLの内部処理・インデックス構成が含まれていないため、`SELECT *` の列、制約、参照整合性、外部DLL経由のCRUD、および性能特性を断定できません。[UNKNOWN: テーブル定義/API定義なし]
7. **性能・データ品質の観点**：`SELECT *` が複数箇所にあり、索引レンジの実効性・全件クリア対象件数・コミット粒度の評価には実テーブル定義と実行計画が必要です（INFERRED）。ソースから閾値・データ件数・実行時間は得られないため、性能上の問題が存在すると断定しません（UNKNOWN）。
